-- =========================================================
-- File: 04_dml_operations.sql
-- Purpose: Demonstrate DML operations
-- Includes UPDATE, DELETE, backup table, and ALTER TABLE
-- =========================================================

UPDATE vehicles
SET mileage = 45500
WHERE vehicle_id = 1

UPDATE drivers
SET phone = '5557778888'
WHERE driver_id = 2

CREATE TABLE vehicles_backup AS
SELECT * FROM vehicles

DELETE FROM fuel_logs
WHERE fuel_id = 3

ALTER TABLE vehicles
ADD notes VARCHAR2(100)

UPDATE vehicles
SET notes = 'Updated after project testing'
WHERE vehicle_id = 1
