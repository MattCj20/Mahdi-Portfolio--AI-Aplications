# Smart Transportation Fleet Management Database

**Student:** Mahdi Mohammadkhani  
**Course:** AI Applications / Database Portfolio  
**Project:** Oracle APEX Physical Database Model

## Project Overview
This project demonstrates how a logical database design can be translated into a physical Oracle SQL database. The database is designed for a smart transportation fleet management system that tracks vehicles, drivers, routes, trip assignments, maintenance records, and fuel logs.

The project includes SQL scripts for:

- Creating relational database tables
- Adding primary keys and foreign keys
- Inserting sample data
- Updating and deleting records
- Creating a backup table
- Running meaningful SELECT queries
- Testing database constraints

## Database Tables

| Table | Purpose |
|---|---|
| `vehicles` | Stores vehicle information such as VIN, make, model, and year |
| `drivers` | Stores driver information and license numbers |
| `routes` | Stores transportation route details |
| `trip_assignments` | Connects vehicles, drivers, and routes |
| `maintenance_records` | Tracks vehicle maintenance services and costs |
| `fuel_logs` | Tracks fuel usage and cost |

## Files Included

| File | Description |
|---|---|
| `01_create_tables.sql` | Creates all database tables |
| `02_add_constraints.sql` | Adds primary keys, unique constraints, check constraints, and foreign keys |
| `03_insert_sample_data.sql` | Inserts sample records into each table |
| `04_dml_operations.sql` | Demonstrates UPDATE, DELETE, ALTER, and backup table creation |
| `05_select_queries.sql` | Includes meaningful SELECT queries for testing and reporting |
| `06_constraint_tests.sql` | Includes intentional success and failure tests for constraints |
| `run_order.txt` | Shows the recommended order for running the scripts in Oracle APEX |

## How to Run in Oracle APEX

1. Open Oracle APEX.
2. Go to **SQL Workshop → SQL Commands**.
3. Copy and paste one statement at a time.
4. Run the files in the order shown in `run_order.txt`.
5. Take screenshots of successful DDL, DML, SELECT, and constraint test results.

## Skills Demonstrated

- SQL DDL and DML
- Primary keys and foreign keys
- Data integrity and constraints
- Relational database design
- Oracle APEX SQL Workshop
- Query writing and testing
- Professional project documentation

## Notes
This project was created as part of a portfolio to showcase database and AI-related coursework to employers.
